begin 
	
	set this load type = L_mixpowder
	wait for 10 sec
	move into conv.sta1
    send to P_conv(V_type)

end


